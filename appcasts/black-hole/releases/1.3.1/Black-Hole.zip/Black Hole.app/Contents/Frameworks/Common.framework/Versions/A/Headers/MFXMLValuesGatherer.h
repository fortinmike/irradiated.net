//
//  MFProviderInfoGatherer.h
//  Buck
//
//  Created by Michaël Fortin on 12-05-14.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MFValuesGatherer.h"

@interface MFXMLValuesGatherer : MFValuesGatherer

@end

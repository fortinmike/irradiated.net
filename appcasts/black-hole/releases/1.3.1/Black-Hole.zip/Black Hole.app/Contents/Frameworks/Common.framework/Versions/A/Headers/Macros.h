//
//  MFGCDMacros.h
//  Common
//
//  Created by Michaël Fortin on 12-08-02.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Common/MFGCDMacros.h>
#import <Common/MFLoggingMacros.h>
//
//  MFMathUtils.h
//  Buck
//
//  Created by Michaël Fortin on 12-06-04.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

@interface MFMathUtils : NSValueTransformer

+ (float)interpolateFrom:(float)from to:(float)to percentage:(float)percentage;

@end

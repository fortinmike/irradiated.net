//
//  MFRecencyToColorValueTransformer.h
//  Buck
//
//  Created by Michaël Fortin on 12-06-03.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <Foundation/Foundation.h>

@interface MFRecencyToColorValueTransformer : NSValueTransformer

@property (copy) NSColor *recentColor;
@property (copy) NSColor *oldColor;
@property (assign) NSTimeInterval oldInterval; // The time interval from *now* to be considered "old".

@end

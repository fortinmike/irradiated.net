//
//  MFFileDeleteQueue.h
//  Black Hole
//
//  Created by Michaël Fortin on 10-08-25.
//  Copyright 2010 Michaël Fortin. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "MFFileDeleter.h"


@protocol MFFileDeleteQueueDelegate
@optional
- (void)fileDeleteQueueDone;
- (void)fileDeleteQueueProgressed:(NSString *)progressMessage;
@end


@interface MFFileDeleteQueue : NSObject <MFFileDeleterDelegate> {
	BOOL running; // YES when currently deleting files in the queue
	BOOL authorization; // YES when authorization is permitted
	int deleteIndex; // The index of the file that is currently being deleted
	
	NSMutableArray *files; // The array of files in the queue
	NSFileManager *fileManager; // A file manager to verify existence of files
	MFFileDeleter *fileDeleter; // The object that implements file deletion itself
	MFFileDeleterSecureDeleteMode secureDeleteMode; // The secure deletion mode to use for all the files in the queue
}

@property (assign) MFFileDeleterSecureDeleteMode secureDeleteMode;
@property (weak) id delegate;

- (void)addFile:(NSString *)file; //
- (void)addFilesFromArray:(NSArray *)array; // Adds files from the NSString array passed as parameter
- (void)addFilesAtPath:(NSString *)path; // Adds all files at the specified path, recursively
- (NSUInteger)count; // Returns the number of items in the queue
- (void)terminate; // Force-terminates the cleaner
- (BOOL)verify; // Verifies if all files in the queue have been deleted
- (void)deleteFiles; // Starts deletion of all files
- (void)deleteNextFile; // Deletes the next file
@end

//
//  MFLogging.h
//  Common
//
//  Created by Michaël Fortin on 12-02-28.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#ifdef DEBUG
	// Inspired by: http://iphoneincubator.com/blog/debugging/the-evolution-of-a-replacement-for-nslog
	#define DLog(fmt, ...) NSLog((@"%s [Line %d] DEBUG: " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);
#else
	#define DLog(...) /* */
#endif

// Inspired by: http://iphoneincubator.com/blog/debugging/the-evolution-of-a-replacement-for-nslog
#define ELog(fmt, ...) NSLog((@"%s [Line %d] ERROR: " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);
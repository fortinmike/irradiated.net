//
//  MFFullscreenWindow.h
//  Sleepytime
//
//  Created by Michaël Fortin on 10-09-26.
//  Copyright 2010 Michaël Fortin. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@protocol MFFullscreenWindowDelegate <NSObject>

- (void)keyDown:(NSEvent *)theEvent;

@end

@interface MFFullscreenWindow : NSWindow {

}

@end

//
//  MFPeriod.h
//  TimedActionsManager
//
//  Created by Michaël Fortin on 11-08-08.
//  Copyright 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum MFPeriodBoundStrictness {
	MFPeriodStartBoundStrict = 0x00000001,
	MFPeriodStartBoundLax = 0x00000010,
	MFPeriodEndBoundStrict = 0x00000100,
	MFPeriodEndBoundLax = 0x00001000,
} MFPeriodBoundStrictness;

@interface MFPeriod : NSObject <NSCopying> {
	
	NSDate *startDate;
	NSDate *endDate;
	
	BOOL startProcessed;
	
	void (^startBlock)();
	void (^endBlock)();
	void (^progressBlock)(float);
	
	int boundsMask; // A bit mask that stores the options for strict and lax bounds
	
}

@property (assign) id userInfo;

@property (nonatomic, copy) NSDate *startDate;
@property (nonatomic, copy) NSDate *endDate;

@property (nonatomic, assign) BOOL startProcessed;

@property (nonatomic, copy) void (^startBlock)();
@property (nonatomic, copy) void (^endBlock)();
@property (nonatomic, copy) void (^progressBlock)(float);

@property (nonatomic, assign) int boundsMask;

@end

//
//  NSImage+Additions.h
//  Common
//
//  Created by Michaël Fortin on 12-07-10.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSImage (Additions)

+ (NSImage *)imageNamed:(NSString *)name inBundle:(NSBundle *)bundle;

@end

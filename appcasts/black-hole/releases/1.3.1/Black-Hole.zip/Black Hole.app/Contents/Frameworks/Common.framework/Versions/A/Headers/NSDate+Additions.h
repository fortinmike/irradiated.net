//
//  NSDate+Additions.h
//  Buck
//
//  Created by Michaël Fortin on 12-05-25.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (Additions)

- (NSInteger)second;
- (NSInteger)minute;
- (NSInteger)hour;
- (NSInteger)day;
- (NSInteger)month;
- (NSInteger)year;

@end

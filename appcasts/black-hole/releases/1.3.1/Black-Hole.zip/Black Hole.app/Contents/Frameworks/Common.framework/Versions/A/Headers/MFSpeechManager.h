//
//  MFTextToSpeech.h
//  Sleepytime
//
//  Created by Michaël Fortin on 11-08-25.
//  Copyright 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MFSpeechManager : NSObject <NSSpeechSynthesizerDelegate> {
	
	NSMutableArray *stringQueue;
	NSSpeechSynthesizer *speechSynth;
	
	BOOL speaking;
	int currentStringIndex;
	
}

- (void)loadSpeechSynthesizer; // Used to manually load the speech synthesizer. If not called, the synth is loaded lazily when required.
- (void)speakTheTime;
- (void)say:(NSString *)string;


#pragma mark Accessor Methods;

- (void)setVoice:(NSString *)voiceIdentifier;
- (NSString *)voice;

@end

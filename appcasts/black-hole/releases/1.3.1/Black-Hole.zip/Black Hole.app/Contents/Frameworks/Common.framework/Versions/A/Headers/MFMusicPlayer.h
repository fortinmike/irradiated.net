//
//  MFMusicPlayer.h
//  MusicPlayerFacade
//
//  Created by Michaël Fortin on 11-08-09.
//  Copyright 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum MFMusicPlayerSpecialValue {
	MFMusicPlayerNoValue = -1,
	MFMusicPlayerVolumeStep = 10,
} MFMusicPlayerSpecialValues;

typedef enum MFMusicPlayerState {
	MFMusicPlayerStateUnknown = -1,
	MFMusicPlayerStatePlaying = 0,
	MFMusicPlayerStatePaused = 1,
	MFMusicPlayerStateStopped = 2,
	MFMusicPlayerStateRewinding = 3,
	MFMusicPlayerStateFastForwarding = 4,
} MFMusicPlayerState;

typedef enum MFMusicPlayerPlaylistKind {
	MFMusicPlayerPlaylistKindLibrary = 0,
	MFMusicPlayerPlaylistKindStandard = 1,
	MFMusicPlayerPlaylistKindPartyShuffle = 2,
	MFMusicPlayerPlaylistKindPurchased = 3,
	MFMusicPlayerPlaylistKindSmart = 4,
	MFMusicPlayerPlaylistKindSleepytimeMusic = 5,
	MFMusicPlayerPlaylistKindSleepytimeSound = 6,
} MFMusicPlayerPlaylistKind;

extern const NSString *MFMusicPlayerPlaylistDescriptionNameKey;
extern const NSString *MFMusicPlayerPlaylistDescriptionKindKey;
extern const NSString *MFMusicPlayerPlaylistDescriptionIdentifierKey;
extern const NSString *MFMusicPlayerPlaylistDescriptionPathKey;

@class MFMusicPlayer;

@protocol MFMusicPlayerDelegate <NSObject>

@optional
- (void)musicPlayerLaunched:(MFMusicPlayer *)musicPlayer;
- (void)musicPlayerQuit:(MFMusicPlayer *)musicPlayer;

@end

@interface MFMusicPlayer : NSObject {
	
	NSString *playerBundleIdentifier;
	
	id __unsafe_unretained delegate;
	
}

@property (nonatomic, unsafe_unretained) id delegate;

@property (nonatomic, copy) NSString *playerBundleIdentifier;

@property (nonatomic, assign) BOOL enabled;

#pragma mark Player Capability Verification Methods
- (BOOL)supportsVolumeRetrieval;
- (BOOL)supportsTrackInfoRetrieval;
- (BOOL)supportsPlayPause;
- (BOOL)supportsPreviousNext;
- (BOOL)supportsRepeatShuffle;
- (BOOL)supportsMusicSelection;

#pragma mark Player Management Methods
- (BOOL)launchPlayerHidden:(BOOL)hidden;
- (void)activatePlayer;
- (BOOL)isRunning;
- (BOOL)canControlPlayer;
- (BOOL)isInstalled;
- (NSImage *)icon16;
- (NSImage *)icon32;
- (NSImage *)iconFull;
- (NSString *)name;
- (void)savePlayerState;
- (void)restorePlayerState;

#pragma mark Player Control Methods
- (BOOL)play;
- (void)playpause;
- (BOOL)playItemWithIdentifier:(long)identifier;
- (void)pause;
- (void)previousTrack;
- (void)nextTrack;
- (BOOL)setVolume:(float)volume;
- (float)volume;
- (void)volumeUp;
- (void)volumeDown;
- (void)setRepeat:(BOOL)repeat;
- (BOOL)repeat;
- (void)setShuffle:(BOOL)shuffle;
- (BOOL)shuffle;
- (void)setCurrentTrackPosition:(NSInteger)position;

#pragma mark Data Gathering Methods
- (NSString *)currentTrackArtist;
- (NSString *)currentTrackAlbum;
- (NSString *)currentTrackTitle;
- (NSInteger)currentTrackRating;
- (NSTimeInterval)currentTrackDuration;
- (NSTimeInterval)currentTrackPosition;
- (NSImage *)currentTrackAlbumArt;
- (BOOL)currentTrackIsStream;
- (NSArray *)playlistDescriptions;
- (MFMusicPlayerState)state;

@end

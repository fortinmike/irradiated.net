//
//  MFTaskRunner.h
//  Common
//
//  Created by Michaël Fortin on 12-07-09.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum MFTaskRunMode {
	MFTaskRunModeAsync,
	MFTaskRunModeSync,
} MFTaskRunMode;

@class MFTaskRunner;

@protocol MFTaskRunnerDelegate <NSObject>

@optional
- (void)taskRunner:(MFTaskRunner *)taskRunner completedWithStatus:(NSNumber *)status data:(NSData *)data;
- (void)taskRunner:(MFTaskRunner *)taskRunner receivedData:(NSData *)data allData:(NSData *)allData;

@end

@interface MFTaskRunner : NSObject {
	
    NSTask *_task;
    
    BOOL _running;
    NSPipe *_pipe;
    NSFileHandle *_fileHandle;
	
}

@property (weak) id delegate;
@property (weak) void (^completionBlock)();

@property (assign) MFTaskRunMode mode;
@property (copy) NSString *command;
@property (copy) NSString *executable;
@property (assign) NSArray *arguments;
@property (readonly) NSMutableData *data;

- (id)initWithCommand:(NSString *)command;

- (void)run;
- (void)terminate;

@end

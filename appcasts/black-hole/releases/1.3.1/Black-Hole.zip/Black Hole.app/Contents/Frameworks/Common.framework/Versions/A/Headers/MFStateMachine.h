//
//  MFStateMachine.h
//  Sleepytime
//
//  Created by Michaël Fortin on 11-08-17.
//  Copyright 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MFState;

@interface MFStateMachine : NSObject {

	NSMutableDictionary *states;
	MFState *currentState;
	
}

#pragma mark State Management Methods
- (void)addStateWithIdentifier:(NSString *)identifier enterBlock:(void (^)())enterBlock exitBlock:(void (^)())exitBlock;
- (void)removeStateWithIdentifier:(NSString *)identifier;
- (NSString *)currentStateIdentifier;

#pragma mark State Transition Methods
- (void)setStateWithoutEntering:(NSString *)identifier;
- (void)enterStateWithIdentifier:(NSString *)identifier;
- (void)exitCurrentState;

@end

//
//  NSMutableArray+Additions.h
//  Common
//
//  Created by Michael Fortin on 2012-08-02.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableArray (Additions)

- (void)addObjectIfNoneEquals:(id)object;

@end

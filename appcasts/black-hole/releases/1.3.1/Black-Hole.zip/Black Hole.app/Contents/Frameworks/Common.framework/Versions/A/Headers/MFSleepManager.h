//
//  MFSleepManager.h
//  Sleepytime
//
//  Created by Michaël Fortin on 10-10-14.
//  Copyright 2010 Michaël Fortin. All rights reserved.
//

#import <Cocoa/Cocoa.h>

typedef enum MFSleepManagerSleepMode {
	MFSleepManagerSleepModeCanSleep = -1,
	MFSleepManagerSleepModeNoIdleSleep = 0,
	MFSleepManagerSleepModeNoDisplaySleep = 1
} MFSleepManagerSleepMode;

@interface MFSleepManager : NSObject {

}

+ (BOOL)enterSleepMode:(int)sleepMode;
+ (BOOL)exitSleepMode:(int)sleepMode;
+ (void)restoreSleep;


#pragma mark "Private" Methods

+ (void)releaseAssertion;
+ (OSStatus)createAssertion:(int)sleepMode;

@end

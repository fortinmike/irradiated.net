//
//  MFBuiltInMusicPlayer.h
//  Sleepytime
//
//  Created by Michaël Fortin on 11-08-24.
//  Copyright 2011 irradiated.net. All rights reserved.
//

#import "MFMusicPlayer.h"

@interface MFBuiltInMusicPlayer : MFMusicPlayer <NSSoundDelegate> {
	
	NSSound *currentSound;
	NSTimer *previewTimer;
	
	NSArray *playlist;
	
	float currentVolume;
	
}

- (BOOL)previewItemWithIdentifier:(long)identifier;

@end

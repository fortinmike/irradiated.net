//
//  NSArray+Additions.h
//  Common
//
//  Created by Michaël Fortin on 12-07-09.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef BOOL (^OperationBlock)(id);

@interface NSArray (Additions)

- (NSArray *)select:(OperationBlock)operation;
- (NSArray *)objectsInRange:(NSRange)range;

@end

//
//  MFSectionBarButton.h
//  Pauses
//
//  Created by Michaël Fortin on 11-12-26.
//  Copyright (c) 2011 irradiated.net. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MFSectionBarButton : NSView {
	
	BOOL _active;
	BOOL _pressed;
	
}

@property (assign) id target;
@property (assign) SEL action;

@property (nonatomic, copy) NSString *identifier;

@property (nonatomic, assign) NSImage *inactiveImage;
@property (nonatomic, assign) NSImage *activeImage;
@property (nonatomic, assign) NSImage *intermediateImage;


#pragma mark Accessor Methods

- (void)setActive:(BOOL)active;
- (BOOL)active;

@end

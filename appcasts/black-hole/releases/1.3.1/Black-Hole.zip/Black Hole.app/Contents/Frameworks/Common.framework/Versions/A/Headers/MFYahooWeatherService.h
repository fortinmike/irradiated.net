//
//  MFYahooWeatherService.h
//  WeatherGrabber
//
//  Created by Michaël Fortin on 11-08-01.
//  Copyright 2011 irradiated.net. All rights reserved.
//

#import "MFWeatherService.h"
#import "MFHTTPRequest.h"

@interface MFYahooWeatherService : MFWeatherService {
	NSString *appId;
	
	MFHTTPRequest *placesRequest;
	MFHTTPRequest *weatherRequest;
	
	NSString *lastPlacesSearch;
	NSString *lastPlaceIdentifier;
	
	NSMutableDictionary *pressureTendencies;
	
	NSMutableData *placesData;
}

@end

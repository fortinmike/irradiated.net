/**
 
 \class MFPathWatcher
 
 MFPathWatcher.h
 Differences

 Created by Michaël Fortin on 11-05-05.
 Copyright 2011 irradiated.net. All rights reserved.
 
 \brief This class is an object-oriented wrapper around the FSEvents C API.
 
 <b>Discussion:</b>
 
 This class encapsulates the bahavior of watching a directory tree for changes.
 The class uses the Observer pattern to warn interested parties of changes.
 Each instance has a "delegate" variable that must be set. This object must
 implement the MFPathWatcherDelegateProtocol which contains a method that will
 be called when the path changes.
 
 The change capture process goes like this:
 -# An FSEvents stream receives the event and triggers the static C callback.
 -# The C callback calls a static method on the MFPathWatcher class, passing
    the changed path as a parameter.
 -# The class method finds the appropriate PathWatcher in a static dictionary
    containing all PathWatcher instances.
 -# The class method calls the pathChangedCallback method on the PathWatcher instance.
 -# The PathWatcher instance calls the appropriate method on its delegate according
    to the MFPathWatcherDelegateProtocol.
 
 FSEvents by definition records that changes happened at the specified path but does
 not record where those changes happened in the directory's subdirectories (if applicable).
 Therefore, this class also has this limitation.
 
 <b>Example usage:</b>
 @verbatim
 MFPathWatcher *pathWatcher = [[MFPathWatcher alloc] initWithPath:@"/User/John"];
 [pathWatcher setDelegate:self];
 [pathWatcher startWatching];
 
 - (void)pathWatcherPathChanged:(id)sender {
	// This method is called each time there is a change in "/User/John".
 }
 @endverbatim
 
 <b>References:</b>
 
 <ul>
 <li><a href="http://developer.apple.com/library/mac/#documentation/Darwin/Conceptual/FSEvents_ProgGuide/TechnologyOverview/TechnologyOverview.html%23//apple_ref/doc/uid/TP40005289-CH3-SW1">FSEvents Technology Overview (Apple Developer)</a></li>
 <li><a href="http://developer.apple.com/library/mac/#documentation/Cocoa/Conceptual/MemoryMgmt/MemoryMgmt.html">Memory Management Programming Guide (Apple Developer)</a></li>
 </ul>

*/

#import <Foundation/Foundation.h>


/**
	\protocol MFPathWatcherDelegateProtocol
	\brief This is the protocol to which an object must conform to receive
           path change notifications from MFPathWatcher. */
@protocol MFPathWatcherDelegateProtocol <NSObject>

- (void)pathWatcherPathChanged:(id)sender;

@end

@interface MFPathWatcher : NSObject {
@private
	FSEventStreamRef stream;
	
	float latency;
	NSString *path;
	
	id<MFPathWatcherDelegateProtocol> __unsafe_unretained delegate;
}

@property (unsafe_unretained) id delegate;
@property (readonly) FSEventStreamRef stream;


#pragma mark Initializers
/// \name Initializers
/// \{

/** This method initializes a new PathWatcher with the specified path.
    The PathWatcher must be started afterwards for it to begin monitoring changes. */
- (id)initWithPath:(NSString *)newPath;

/// \}


#pragma mark Path Watching Methods
/// \name Path Watching Methods
/// \{

/** This method sets up an FSEvents stream for the speficied path.  */
- (BOOL)setupFSEventsStreamForPath:(NSString *)pathToWatch;

/** This is the static FSEvents C callback that is called by all streams when they detect a change. */
static void fseventsCallback(ConstFSEventStreamRef streamRef, void *clientCallBackInfo, size_t numEvents,
							 void *eventPaths, const FSEventStreamEventFlags eventFlags[], const FSEventStreamEventId eventIds[]);

/** This static (class) method is called by the FSEvents callback to dispatch the "changed" message to the appropriate PathWatcher. */
+ (void)sendPathChangedMessageToInstanceWithPath:(NSString *)path;

/** This instance method is called by sendPathChangedMessageToInstanceWithPath: when
    the instance is detected as being the host of the detected path change. */
- (void)pathChangedCallback;

/** This method stops, unschedules and releases the FSEvents stream. */
- (void)invalidateAndReleaseFSEventsStream;

/** Starts watching for incoming FSEvent change notifications. */
- (void)startWatching;

/** Stops watching for incoming FSEvent change notifications. */
- (void)stopWatching;

/// \}


#pragma mark Accessor Methods

- (BOOL)setPath:(NSString *)newPath;
- (NSString *)path;
- (void)setLatency:(float)newLatency;
- (int)latency;

@end

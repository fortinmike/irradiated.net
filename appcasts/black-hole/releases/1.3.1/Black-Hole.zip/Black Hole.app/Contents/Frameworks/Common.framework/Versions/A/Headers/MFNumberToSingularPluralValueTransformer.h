//
//  MFNumberToSingularPluralValueTransformer.h
//  Common
//
//  Created by Michaël Fortin on 10-09-27.
//  Copyright 2010 Michaël Fortin. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface MFNumberToSingularPluralValueTransformer : NSValueTransformer {
	NSString *plural;
	NSString *singular;
}

- (id)initWithSingular:(NSString *)singularString plural:(NSString *)pluralString; // Initializes an instance with custom singular and plural return values

@end

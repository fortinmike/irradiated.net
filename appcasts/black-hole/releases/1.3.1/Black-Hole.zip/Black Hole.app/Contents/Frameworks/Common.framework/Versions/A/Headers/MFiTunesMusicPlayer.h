//
//  MFiTunesMusicPlayer.h
//  MusicPlayerFacade
//
//  Created by Michaël Fortin on 11-08-09.
//  Copyright 2011 irradiated.net. All rights reserved.
//

#import "MFMusicPlayer.h"

@class iTunesApplication;

@interface MFiTunesMusicPlayer : MFMusicPlayer {
	
	iTunesApplication *iTunes;
	
	BOOL wasPlaying;
	NSInteger previousPlaylistId;
	NSInteger previousTrackId;
	
}

@end

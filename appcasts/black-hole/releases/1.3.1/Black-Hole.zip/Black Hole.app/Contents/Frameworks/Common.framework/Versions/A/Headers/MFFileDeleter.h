//
//  FileDeleter.h
//  Black Hole
//
//  Created by Michaël Fortin on 10-07-15.
//  Copyright 2010 Michaël Fortin. All rights reserved.
//
//  Description: This class implements file deleting functionality.
//               Files can be deleted normally or securely.
//

#import <Cocoa/Cocoa.h>

// Secure deletion modes
typedef enum MFFileDeleterSecureDeleteMode {
	MFSecureModeOff = -1,
	MFSecureModeSimple = 0,
	MFSecureMode7Pass = 1,
	MFSecureMode35Pass = 2
} MFFileDeleterSecureDeleteMode;

// Delegate protocol
@protocol MFFileDeleterDelegate
@optional
- (void)fileDeleterProgressed:(NSString *)text;
- (void)fileDeleterDone;
@end


@interface MFFileDeleter : NSObject {
	BOOL deleting; // This is equal to YES if the MFFileDeleter instance is currently deleting a file
	
	NSTask *task; // The task used to run rm or srm
	NSPipe *pipe; // The pipe used to obtain output
	NSFileHandle *fileHandle; // Used to obtain output
}

@property (weak) id delegate;

- (NSString *)deleteFile:(NSString *)filePath secureMode:(int)secureMode asynchronously:(BOOL)async;
- (void)terminate; // Force-terminates deletion, killing the task if required
- (void)doneRunning:(NSNotification *)notification;

@end

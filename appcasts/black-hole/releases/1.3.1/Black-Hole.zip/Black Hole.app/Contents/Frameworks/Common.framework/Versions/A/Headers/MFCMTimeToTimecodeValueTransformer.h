//
//  MFCMTimeToTimecodeValueTransformer.h
//  ClipCut
//
//  Created by Michaël Fortin on 12-01-13.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreMedia/CoreMedia.h>

@interface MFCMTimeToTimecodeValueTransformer : NSValueTransformer

#pragma mark Accessor Methods

+ (void)setFramerate:(NSInteger)framerate;

@end

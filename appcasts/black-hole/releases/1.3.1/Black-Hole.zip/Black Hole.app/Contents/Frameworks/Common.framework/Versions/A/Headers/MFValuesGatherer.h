//
//  MFValuesGatherer.h
//  Buck
//
//  Created by Michaël Fortin on 12-05-15.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MFHTTPRequest.h"

#define MFValuesGathererErrorDomain @"MFValuesGathererErrorDomain"

#define kMFErrorCouldNotOpenDocument 1000
#define kMFErrorInvalidQuery 1001
#define kMFErrorCouldNotObtainAllValues 1002

@class MFValuesGatherer;

@protocol MFValuesGathererDelegate <NSObject>

- (void)valuesGatherer:(MFValuesGatherer *)gatherer succeededForURL:(NSURL *)url withValues:(NSDictionary *)values;
- (void)valuesGatherer:(MFValuesGatherer *)gatherer failedForURL:(NSURL *)url withError:(NSError *)error;

@end

@interface MFValuesGatherer : NSObject <MFHTTPRequestDelegate> {
	
	// State
	bool _gathering;
	
	// Other
	MFHTTPRequest *_httpRequest;
	NSMutableDictionary *_keyAndQueryPairs;
	
}

@property (retain) id<MFValuesGathererDelegate> delegate;

@property (copy) NSURL *url;
@property (assign) NSStringEncoding encoding;

- (id)initWithURL:(NSURL *)url;

- (NSDictionary *)processData:(NSData *)data;

- (void)addValueQuery:(NSString *)xQuery withKey:(NSString *)key;
- (void)removeValueQueryWithKey:(NSString *)key;
- (void)removeAllValueQueries;

- (void)updateInfo;

- (void)failed:(NSInteger)errorCode innerError:(NSError *)innerError;

@end

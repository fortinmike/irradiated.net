/**
 
 \class MFBackgroundView
 
 MFBackgroundView.h
 Differences
 
 Created by Michaël Fortin on 11-06-02.
 Copyright 2011 irradiated.net. All rights reserved.
 
 \brief An NSView subclass that displays a three-part image as its background.
 
 <b>Discussion:</b>
 If three images are supplied (left, middle and right), the left image will be drawn once
 at the left of the view, the right image will be drawn once at the right of the view
 and the middle one will be tiled (if specified) across the whole middle section. The fact
 that this view draws its background using three images makes it scalable horizontally
 while preventing its contents from being stretched and distorted.
 
 Its images can be set in Interface Builder by using user defined runtime attributes.
 If the appropriate property names are used (based on the accessors' selectors), the color will
 be set at runtime through KVC, invoking the accessors.

*/

#import <Cocoa/Cocoa.h>


@interface MFBackgroundView : NSView {
@private
    
	BOOL tile; ///< Whether the middle image will be tiled to fill the view's width instead of stretched
	
	NSImage *leftImage;
	NSImage *rightImage;
	NSImage *middleImage;
	
}

@property (nonatomic, assign) BOOL tile;


#pragma mark Setter Methods

- (void)setLeftImageName:(NSString *)leftImageName;
- (void)setRightImageName:(NSString *)rightImageName;
- (void)setMiddleImageName:(NSString *)middleImageName;

@end

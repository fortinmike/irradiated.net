//
//  MFTrigger.h
//  Buck
//
//  Created by Michaël Fortin on 12-05-22.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MFTrigger;

typedef void (^MFStateChangedBlock)(BOOL newValue);
typedef BOOL (^MFTestBlock)(MFTrigger *trigger);

@interface MFTrigger : NSObject {
	
	MFStateChangedBlock _stateChangedBlock;
	MFTestBlock _testBlock;
	NSMutableDictionary *_watchedProperties;
    
    BOOL _firstTestCompleted;
	
}

@property (assign) BOOL state;

// Watch a property and assign it a key.
// You can obtain this property's value using valueForKey: in the test block.
- (void)watchKeyPath:(NSString *)keyPath ofObject:(id)object assignKey:(NSString *)key;

// A handler that can be used to listen to trigger value changes.
- (void)setStateChangedHandler:(MFStateChangedBlock)block;

// Set a block to run when values change.
// The trigger value will be set to the result of running this block.
- (void)setTestBlock:(MFTestBlock)testBlock testNow:(BOOL)testNow;

// Should be used inside the test block to test the values.
- (id)valueForKey:(NSString *)key;

@end

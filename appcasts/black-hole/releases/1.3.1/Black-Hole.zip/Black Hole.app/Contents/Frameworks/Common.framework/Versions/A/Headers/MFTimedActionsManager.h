//
//  MFTimedActionsManager.h
//  TimedActionsManager
//
//  Created by Michaël Fortin on 11-08-08.
//  Copyright 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MFPeriod.h"
#import "MFMoment.h"

typedef enum MFInterval {
	kMFAutomaticInterval = -1,
} MFInterval;

@interface MFTimedActionsManager : NSObject {
	
	NSTimer *actionTimer;
	float actionInterval;
	float progressInterval;
	
	NSMutableDictionary *groups;
	NSMutableArray *periods;
	NSMutableArray *moments;
	
	NSMutableArray *progressTimers;
	
}

@property (readonly) NSMutableDictionary *groups;
@property (readonly) NSMutableArray *periods;
@property (readonly) NSMutableArray *moments;

@property (assign) float actionInterval;
@property (assign) float progressInterval;


#pragma mark Period and Moment Management Methods
- (BOOL)addPeriod:(MFPeriod *)newPeriod toGroup:(NSString *)groupIdentifier;
- (BOOL)addMoment:(MFMoment *)newMoment toGroup:(NSString *)groupIdentifier;
- (void)removeAllGroups;
- (void)removeAllButGroup:(NSString *)groupIdentifier;
- (void)removeGroup:(NSString *)group;


#pragma mark Playback Methods
- (void)startTimingActions;
- (void)stopTimingActions;


#pragma mark Convenience Methods
- (NSTimeInterval)updateIntervalForTimeInterval:(NSTimeInterval)duration;

@end

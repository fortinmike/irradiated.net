//
//  MFDatePicker.h
//  Sleepytime
//
//  Created by Michaël Fortin on 10-12-18.
//  Copyright 2010 Michaël Fortin. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface MFDatePicker : NSDatePicker {

}

@end
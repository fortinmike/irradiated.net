//
//  MFMusicPlayerController.h
//  Pauses
//
//  Created by Michaël Fortin on 11-12-31.
//  Copyright (c) 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MFTimedActionsManager;
@class MFMoment;
@class MFMusicPlayer;

@interface MFMusicPlayerController : NSObject {

	float _originalVolume;
	float _musicVolume;
	NSInteger _musicIdentifier;
	float _fadeInStartVolume;
	float _fadeOutStartVolume;
	BOOL _previousShuffle;
	BOOL _shuffle;
	MFTimedActionsManager *_timedActionsManager;
	
}

@property (retain) MFMusicPlayer *player;

- (void)pauseAndFadeOut:(NSTimeInterval)timeInterval;
- (void)resumeAndFadeIn:(NSTimeInterval)timeInterval;
- (void)startMusic:(NSInteger)musicIdentifier andFadeIn:(NSTimeInterval)timeInterval shuffle:(BOOL)shuffle;
- (void)stopMusicAndFadeOut:(NSTimeInterval)timeInterval;


#pragma mark Convenience Methods

- (MFMoment *)stopTimingMoment:(NSDate *)date;


#pragma mark MFTimedActionsManager Callbacks (Pause/Resume)

- (void)pauseStart;
- (void)pauseProgress:(float)progress;
- (void)pauseEnd;
- (void)resumeStart;
- (void)resumeProgress:(float)progress;
- (void)resumeEnd;

- (void)startMusicStart;
- (void)startMusicProgress:(float)progress;
- (void)startMusicEnd;
- (void)stopMusicStart;
- (void)stopMusicProgress:(float)progress;
- (void)stopMusicEnd;

- (void)stopTiming;

@end

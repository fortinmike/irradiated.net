//
//  MFWeatherService.h
//  WeatherGrabber
//
//  Created by Michaël Fortin on 11-08-01.
//  Copyright 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MFWeatherService;

// Unit types
typedef enum MFWeatherServiceUnit {
	kMFWeatherServiceCelcius = 0,
	kMFWeatherServiceFahrenheit = 1,
} MFWeatherServiceUnit;

// Error types
typedef enum MFWeatherErrorCodes {
	kMFWeatherServiceFailedRequestError = 0,
	kMFWeatherServiceNoPlacesFoundError = 1,
	kMFWeatherServiceNoWeatherDataFoundError = 2,
} MFWeatherErrorCodes;

// Unit string keys
extern NSString *const kMFTemperatureUnit;
extern NSString *const kMFDistanceUnit;
extern NSString *const kMFPressureUnit;
extern NSString *const kMFSpeedUnit;

// Delegate protocol
@protocol MFWeatherServiceDelegate <NSObject>

@optional
- (void)weatherService:(MFWeatherService *)service finishedPlacesLookupForSearchString:(NSString *)search places:(NSArray *)foundPlaces;
- (void)weatherService:(MFWeatherService *)service failedPlacesLookupWithErrorCode:(MFWeatherErrorCodes)errorCode;
- (void)weatherService:(MFWeatherService *)service finishedWeatherLookupForPlaceIdentifier:(NSString *)placeIdentifier conditions:(NSDictionary *)conditions units:(NSDictionary *)units;
- (void)weatherService:(MFWeatherService *)service failedWeatherLookupWithErrorCode:(MFWeatherErrorCodes)errorCode;

@end

@interface MFWeatherService : NSObject {
	
	id __unsafe_unretained delegate;
	
}

@property (nonatomic, unsafe_unretained) id delegate;

- (void)startPlacesLookupForSearchString:(NSString *)search;
- (void)startWeatherLookupForPlaceIdentifier:(NSString *)placeIdentifier withUnit:(MFWeatherServiceUnit)unit;

@end

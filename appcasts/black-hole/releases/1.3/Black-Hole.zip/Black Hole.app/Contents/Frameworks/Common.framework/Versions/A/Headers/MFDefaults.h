//
//  MFDefaults.h
//  Pauses
//
//  Created by Michaël Fortin on 11-11-28.
//  Copyright (c) 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MFMutableDictionary.h"

@interface MFDefaults : NSObject <MFMutableDictionaryDelegate> {
	
	MFMutableDictionary *_volatileDefaults;
	NSMutableDictionary *_defaultsSnapshot;
	
	NSArray *_registeredKeys;
	
}

@property (retain) MFMutableDictionary *volatileDefaults;


#pragma mark Singleton Methods

+ (id)defaults;


#pragma mark Defaults Loading and Sync Methods

- (void)registerDefaults:(NSDictionary *)defaults; ///< Same as NSUserDefaults equivalent.
- (void)registerDefaultsNamed:(NSString *)name; ///< Registers all defaults from the plist named [name] in the app's resources.
- (BOOL)isKeyRegistered:(NSString *)key; ///< Indicates whether a key is registered or not. Only volatile defaults with registered keys are applied.
- (void)applyVolatileObjects; ///< Applies all volatile objects into the standard user defaults (NSUserDefaults).
- (void)applyVolatileObjectWithKey:(NSString *)key; ///< Applies a single object into the standard user defaults (NSUserDefaults).
- (void)discardVolatileObjects; ///< Discards all volatile objects from the volatile user defaults dictionary.
- (void)discardVolatileObjectWithKey:(NSString *)key; ///< Discards a single volatile object from the volatile user defaults dictionary.
- (BOOL)synchronize; ///< Synchronizes the standard user defaults (NSUserDefaults).
- (BOOL)hasUnappliedVolatileDefaults; ///< Tells whether there are volatile user defaults that haven't been applied into the standard user defaults.


#pragma mark Object Access Methods

- (void)setObject:(id)object forKey:(id)key; ///< Sets the object for the specified key, in both the standard user defaults and volatile user defaults.
- (id)objectForKey:(NSString *)key; ///< Returns the non-volatile object for the specified key from the standard user defaults.
- (void)setVolatileObject:(id)object forKey:(NSString *)key; ///< Sets only the volatile object for the specified key.
- (id)volatileObjectForKey:(NSString *)key; ///< Returns the volatile object for the specified key.


#pragma mark Type-Specific Object Access Methods

- (NSInteger)integerForKey:(NSString *)key; ///< Returns an integer for the specified key.
- (NSInteger)integerForVolatileKey:(NSString *)key; ///< Returns an integer for the specified key in the volatile user defaults.
- (NSInteger)longForKey:(NSString *)key; ///< Returns a long for the specified key.
- (NSInteger)longForVolatileKey:(NSString *)key; ///< Returns a long for the specified key in the volatile user defaults.
- (BOOL)boolForKey:(NSString *)key; ///< Returns a bool for the specified key.
- (BOOL)boolForVolatileKey:(NSString *)key; ///< Returns a bool for the specified key in the volatile user defaults.
- (NSString *)stringForKey:(NSString *)key; ///< Returns a string for the specified key.
- (NSString *)stringForVolatileKey:(NSString *)key; ///< Returns a string for the specified key in the volatile user defaults.


#pragma mark Key-Value Coding Methods

- (void)setValue:(id)value forKey:(NSString *)key; ///< Sets the object for the specified key. Called automatically by bindings.
- (id)valueForKey:(NSString *)key; ///< Returns the object for the specified key. Called automatically by bindings.

@end

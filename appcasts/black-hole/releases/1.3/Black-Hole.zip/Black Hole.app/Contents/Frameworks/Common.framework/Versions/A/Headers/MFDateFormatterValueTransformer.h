//
//  MFDateFormatterValueTransformer.h
//  Buck
//
//  Created by Michaël Fortin on 12-05-19.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MFDateFormatterValueTransformer : NSValueTransformer

@property (retain) NSDateFormatter *dateFormatter;

@end

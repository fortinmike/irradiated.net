//
//  MFRdioMusicPlayer.h
//  Sleepytime
//
//  Created by Michaël Fortin on 11-08-19.
//  Copyright 2011 irradiated.net. All rights reserved.
//

#import "MFMusicPlayer.h"

@class RdioApplication;

@interface MFRdioMusicPlayer : MFMusicPlayer {
	
	RdioApplication *rdio;
	
}

@end

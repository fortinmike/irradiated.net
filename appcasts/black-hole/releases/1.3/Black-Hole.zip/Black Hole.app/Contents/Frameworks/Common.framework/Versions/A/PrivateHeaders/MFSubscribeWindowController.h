//
//  MFSubscribeWindowController.h
//  Common
//
//  Created by Michaël Fortin on 11-12-18.
//  Copyright (c) 2011 irradiated.net. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class MFHTTPRequest;

@interface CCSubscribeWindowController : NSWindowController {
	
	MFHTTPRequest *_request;
	
}

@property (assign) NSString *header; // Header text bound to this var.
@property (assign) NSString *email; // Email field bound to this var.
@property (retain) NSURL *reviewURL; // URL for the review button.
@property (retain) NSImage *reviewButtonImage; // The image that's displayed in the review button.

@property (unsafe_unretained) IBOutlet NSView *containerView;
@property (strong) IBOutlet NSView *thanksView;
@property (strong) IBOutlet NSView *subscribeView;
@property (unsafe_unretained) IBOutlet NSButton *subscribeButton;
@property (unsafe_unretained) IBOutlet NSImageView *iconImageView;

- (id)initWithWindow;

#pragma mark Action Methods

- (IBAction)subscribeButton_clicked:(id)sender;
- (IBAction)reviewButton_clicked:(id)sender;
- (IBAction)twitterButton_clicked:(id)sender;


#pragma mark Convenience Methods

- (BOOL)validateEmail:(NSString *)email;

@end

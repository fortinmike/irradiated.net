//
//  MFHTTPRequest.h
//  WeatherGrabber
//
//  Created by Michaël Fortin on 11-07-31.
//  Copyright 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

#define MFHTTPRequestArgumentsContentType @"application/x-www-form-urlencoded"

@class MFHTTPRequest;

@protocol MFHTTPRequestDelegate
@optional
- (void)httpRequest:(MFHTTPRequest *)request succeededWithData:(NSData *)data;
- (void)httpRequest:(MFHTTPRequest *)request failedWithError:(NSError *)error;
@end

@interface MFHTTPRequest : NSObject {
	
}

@property (nonatomic, retain) id delegate;
@property (nonatomic, copy) NSString *httpMethod;
@property (nonatomic, copy) NSString *contentType;
@property (nonatomic, assign) int timeoutInterval;
@property (nonatomic, copy) NSURL *url;
@property (nonatomic, copy) NSString *body;

- (void)submit;

@end

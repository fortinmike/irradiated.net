//
//  MFiTunesMusicPlayer.h
//  MusicPlayerFacade
//
//  Created by Michaël Fortin on 11-08-09.
//  Copyright 2011 irradiated.net. All rights reserved.
//

#import "MFMusicPlayer.h"

@class RadiolineApplication;

@interface MFRadiolineMusicPlayer : MFMusicPlayer {
	
	RadiolineApplication *radioline;
	
	BOOL wasPlaying;
	NSInteger previousPlaylistId;
	NSInteger previousTrackId;
	
}

@end

//
//  MFPipeValueTransformer.h
//  Buck
//
//  Created by Michaël Fortin on 12-06-04.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MFValueTransformerGroup : NSValueTransformer {
	
	NSMutableArray *_valueTransformers;
	
}

- (void)addValueTransformer:(NSValueTransformer *)transformer;
- (void)insertValueTransformer:(NSValueTransformer *)transformer atIndex:(NSInteger)index;

@end

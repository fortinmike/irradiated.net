//
//  MFSystemMusicPlayer.h
//  Sleepytime
//
//  Created by Michaël Fortin on 11-10-31.
//  Copyright (c) 2011 irradiated.net. All rights reserved.
//

#import <AudioToolbox/AudioServices.h>
#import "MFMusicPlayer.h"

@interface MFSystemMusicPlayer : MFMusicPlayer {
	
}

+ (float)volume;
+ (void)setVolume:(Float32)newVolume;
+ (AudioDeviceID)defaultOutputDeviceID;

@end

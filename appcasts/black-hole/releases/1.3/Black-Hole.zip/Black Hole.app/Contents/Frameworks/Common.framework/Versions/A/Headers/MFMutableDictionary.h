//
//  MFMutableDictionary.h
//  Pauses
//
//  Created by Michaël Fortin on 11-12-23.
//  Copyright (c) 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MFMutableDictionary;

@protocol MFMutableDictionaryDelegate <NSObject>

- (void)valueChangedInDictionary:(MFMutableDictionary *)dictionary forKey:(NSString *)key;

@end

@interface MFMutableDictionary : NSObject {
	
}

@property (assign) id<MFMutableDictionaryDelegate> delegate;
@property (retain) NSMutableDictionary *dictionary;

- (void)setObject:(id)anObject forKey:(id)aKey;
- (void)removeObjectForKey:(id)aKey;
- (NSUInteger)count;
- (id)objectForKey:(id)aKey;
- (NSEnumerator *)keyEnumerator;
- (NSArray *)allKeys;
- (void)replaceWithContentsOfDictionary:(MFMutableDictionary *)dictionary;


#pragma mark Convenience Methods

- (void)notifyDelegateOfChangesForKey:(NSString *)key;

@end

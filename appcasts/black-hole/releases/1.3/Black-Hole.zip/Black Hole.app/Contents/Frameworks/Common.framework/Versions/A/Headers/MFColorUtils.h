//
//  MFColorUtils.h
//  ProPicker
//
//  Created by Michaël Fortin on 12-02-07.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MFColorUtils : NSObject

+ (void)getR:(float *)r g:(float *)g b:(float *)b fromH:(float)hue s:(float)saturation b:(float)brightness; // All values between 0 and 1
+ (void)getH:(float *)h s:(float *)s b:(float *)b fromR:(float)red g:(float)green b:(float)blue; // All values between 0 and 1

@end

//
//  MFSectionBarController.h
//  Pauses
//
//  Created by Michaël Fortin on 11-12-26.
//  Copyright (c) 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MFSectionBarController;

@protocol MFSectionBarControllerDelegate <NSObject>

- (void)sectionBar:(MFSectionBarController *)sectionBar selectionChangedTo:(NSString *)identifier;

@end

@interface MFSectionBarController : NSViewController {
	
	NSInteger _currentX;
	NSString *_selectedSectionIdentifier;
	
	NSMutableArray *_sectionButtons;
	
}

@property (nonatomic, assign) id<MFSectionBarControllerDelegate> delegate;
@property (nonatomic, copy) NSImage *separatorImage;


#pragma mark Setup Methods

- (void)addSectionWithIdentifier:(NSString *)identifier inactiveImage:(NSImage *)inactiveImage activeImage:(NSImage *)activeImage  intermediateImage:(NSImage *)intermediateImage;


#pragma mark Control Methods

- (void)selectSectionWithIdentifier:(NSString *)identifier;
- (NSString *)selectedSectionIdentifier;
- (void)selectSectionAtIndex:(NSInteger)index;
- (NSInteger)indexOfSelectedSection;

@end

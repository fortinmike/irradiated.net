//
//  MFGCDMacros.h
//  Common
//
//  Created by Michaël Fortin on 12-06-08.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#define dispatch_async_background(block) dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, NULL), block);
#define dispatch_async_default(block) dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, NULL), block);
#define dispatch_async_high(block) dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, NULL), block);
#define dispatch_async_low(block) dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, NULL), block);

#define dispatch_sync_background(block) dispatch_sync(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, NULL), block);
#define dispatch_sync_default(block) dispatch_sync(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, NULL), block);
#define dispatch_sync_high(block) dispatch_sync(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, NULL), block);
#define dispatch_sync_low(block) dispatch_sync(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, NULL), block);

#define dispatch_async_main(block) dispatch_async(dispatch_get_main_queue(), block);
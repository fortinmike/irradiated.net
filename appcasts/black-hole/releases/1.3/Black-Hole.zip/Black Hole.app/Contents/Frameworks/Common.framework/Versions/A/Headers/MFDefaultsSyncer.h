//
//  MFPreferencesSyncer.h
//  Buck
//
//  Created by Michaël Fortin on 12-05-21.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MFDefaultsSyncer : NSObject

+ (void)syncKeyPath:(NSString *)keyPath ofObject:(id)object withDefaultsKey:(NSString *)key;
+ (void)unsyncDefaultsKey:(NSString *)key;

@end

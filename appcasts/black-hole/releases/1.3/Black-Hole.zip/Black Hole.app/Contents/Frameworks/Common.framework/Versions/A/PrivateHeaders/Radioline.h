/*
 * Radioline.h
 */

#import <AppKit/AppKit.h>
#import <ScriptingBridge/ScriptingBridge.h>


@class RadiolineApplication, RadiolineDocument, RadiolineWindow;

enum RadiolineSaveOptions {
	RadiolineSaveOptionsYes = 'yes ' /* Save the file. */,
	RadiolineSaveOptionsNo = 'no  ' /* Do not save the file. */,
	RadiolineSaveOptionsAsk = 'ask ' /* Ask the user whether or not to save the file. */
};
typedef enum RadiolineSaveOptions RadiolineSaveOptions;

enum RadiolinePrintingErrorHandling {
	RadiolinePrintingErrorHandlingStandard = 'lwst' /* Standard PostScript error handling */,
	RadiolinePrintingErrorHandlingDetailed = 'lwdt' /* print a detailed report of PostScript errors */
};
typedef enum RadiolinePrintingErrorHandling RadiolinePrintingErrorHandling;



/*
 * Standard Suite
 */

// The application's top-level scripting object.
@interface RadiolineApplication : SBApplication

- (SBElementArray *) documents;
- (SBElementArray *) windows;

@property (copy, readonly) NSString *name;  // The name of the application.
@property (readonly) BOOL frontmost;  // Is this the active application?
@property (copy, readonly) NSString *version;  // The version number of the application.

- (id) open:(id)x;  // Open a document.
- (void) print:(id)x withProperties:(NSDictionary *)withProperties printDialog:(BOOL)printDialog;  // Print a document.
- (void) quitSaving:(RadiolineSaveOptions)saving;  // Quit the application.
- (BOOL) exists:(id)x;  // Verify that an object exists.
- (void) play;  // Play the current station
- (void) pause;  // Pause audio player
- (void) playpause;  // Toggle between play and pause
- (void) next;  // Play next station from current list
- (void) previous;  // Play previous station from current list
- (NSInteger) getVolume;  // Obtain current volume
- (void) setVolume:(NSInteger)x;  // Set current volume
- (NSString *) getStationName;  // Obtain current station name
- (NSString *) getTrackName;  // Obtain current track name
- (NSString *) getArtistName;  // Obtain current artist name
- (NSInteger) getPlayerStatus;  // Obtain current player status

@end

// A document.
@interface RadiolineDocument : SBObject

@property (copy, readonly) NSString *name;  // Its name.
@property (readonly) BOOL modified;  // Has it been modified since the last save?
@property (copy, readonly) NSURL *file;  // Its location on disk, if it has one.

- (void) closeSaving:(RadiolineSaveOptions)saving savingIn:(NSURL *)savingIn;  // Close a document.
- (void) saveIn:(NSURL *)in_ as:(id)as;  // Save a document.
- (void) printWithProperties:(NSDictionary *)withProperties printDialog:(BOOL)printDialog;  // Print a document.
- (void) delete;  // Delete an object.
- (void) duplicateTo:(SBObject *)to withProperties:(NSDictionary *)withProperties;  // Copy an object.
- (void) moveTo:(SBObject *)to;  // Move an object to a new location.

@end

// A window.
@interface RadiolineWindow : SBObject

@property (copy, readonly) NSString *name;  // The title of the window.
- (NSInteger) id;  // The unique identifier of the window.
@property NSInteger index;  // The index of the window, ordered front to back.
@property NSRect bounds;  // The bounding rectangle of the window.
@property (readonly) BOOL closeable;  // Does the window have a close button?
@property (readonly) BOOL miniaturizable;  // Does the window have a minimize button?
@property BOOL miniaturized;  // Is the window minimized right now?
@property (readonly) BOOL resizable;  // Can the window be resized?
@property BOOL visible;  // Is the window visible right now?
@property (readonly) BOOL zoomable;  // Does the window have a zoom button?
@property BOOL zoomed;  // Is the window zoomed right now?
@property (copy, readonly) RadiolineDocument *document;  // The document whose contents are displayed in the window.

- (void) closeSaving:(RadiolineSaveOptions)saving savingIn:(NSURL *)savingIn;  // Close a document.
- (void) saveIn:(NSURL *)in_ as:(id)as;  // Save a document.
- (void) printWithProperties:(NSDictionary *)withProperties printDialog:(BOOL)printDialog;  // Print a document.
- (void) delete;  // Delete an object.
- (void) duplicateTo:(SBObject *)to withProperties:(NSDictionary *)withProperties;  // Copy an object.
- (void) moveTo:(SBObject *)to;  // Move an object to a new location.

@end


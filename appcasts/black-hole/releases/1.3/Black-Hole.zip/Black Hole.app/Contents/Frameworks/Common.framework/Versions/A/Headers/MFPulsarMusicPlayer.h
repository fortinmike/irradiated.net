//
//  MFPulsarMusicPlayer.h
//  Sleepytime
//
//  Created by Michaël Fortin on 11-08-19.
//  Copyright 2011 irradiated.net. All rights reserved.
//

#import "MFMusicPlayer.h"

@class PulsarApplication;

@interface MFPulsarMusicPlayer : MFMusicPlayer {
	
	PulsarApplication *pulsar;
	
}

@end

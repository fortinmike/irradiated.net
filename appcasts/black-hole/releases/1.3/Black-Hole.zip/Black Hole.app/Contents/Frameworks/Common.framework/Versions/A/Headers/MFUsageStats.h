//
//  MFUsageStats.h
//  Common
//
//  Created by Michaël Fortin on 11-10-26.
//  Copyright (c) 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MFUsageStats : NSObject {
	
}

#pragma mark Manual Stats

+ (void)increment:(NSString *)key; // Increments the counter value for the specified key.
+ (void)setBool:(BOOL)value forKey:(NSString *)key; // Sets the value of the key to YES or NO.
+ (void)averageNumber:(float)number forKey:(NSString *)key; // Sets the value for the key to the average of all values passed historically.
+ (void)averageInterval:(NSDate *)date forKey:(NSString *)key; // Sets the value for the key to the average interval between all dates passed historically.
+ (void)incrementString:(id)string inCollectionWithKey:(NSString *)key; // Increments the count of a string in the collection with the specified key.


#pragma mark Automatic Stats

+ (void)watchPreferenceWithKey:(NSString *)preferencesKey; // Makes MFUsageStats automatically copy the specified preferences when stats are saved.


#pragma mark Convenience Methods

+ (void)saveStats;
+ (void)sendStatsIgnoringPreference:(BOOL)ignore;

@end

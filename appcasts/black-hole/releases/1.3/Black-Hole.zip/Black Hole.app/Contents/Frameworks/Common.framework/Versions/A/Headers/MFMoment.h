//
//  MFMoment.h
//  TimedActionsManager
//
//  Created by Michaël Fortin on 11-08-08.
//  Copyright 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MFMoment : NSObject {
	
	NSDate *date;
	
	BOOL processed;
	
	void (^actionBlock)();
	
}

@property (nonatomic, copy) NSDate *date;

@property (nonatomic, assign) BOOL processed;

@property (nonatomic, copy) void (^actionBlock)();

@end

//
//  MFState.h
//  Sleepytime
//
//  Created by Michaël Fortin on 11-08-17.
//  Copyright 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MFState : NSObject {
	
	NSString *identifier;
	void (^enterBlock)();
	void (^exitBlock)();
	SEL enterSelector;
	SEL exitSelector;
	
}

@property (copy) NSString *identifier;
@property (readwrite, copy) void (^enterBlock)();
@property (readwrite, copy) void (^exitBlock)();

@end

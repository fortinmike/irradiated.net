//
//  MFTimeUtils.h
//  Common
//
//  Created by Michaël Fortin on 09-09-24.
//  Copyright 2009 Michaël Fortin. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#define SECONDS_IN_MINUTE 60
#define SECONDS_IN_HOUR 60 * 60
#define SECONDS_IN_DAY 60 * 60 * 24

enum {
	MFTimeUnitSeconds = 0,
	MFTimeUnitMinutes = 1,
	MFTimeUnitHours = 2,
	MFTimeUnitDays = 3,
};
typedef NSUInteger MFTimeUnit;

enum {
	MFTimeRoundModeFloor = 0,
	MFTimeRoundModeCeil = 1,
	MFTimeRoundModeRound = 2,
	MFTimeRoundModeAuto = 3,
};
typedef NSUInteger MFTimeRoundMode;


@interface MFTimeUtils : NSObject {

}

+ (unsigned)unitFlags;
+ (MFTimeUnit)idealTimeUnitForInterval:(NSTimeInterval)interval;
+ (int)amountForInterval:(NSTimeInterval)interval withTimeUnit:(MFTimeUnit)timeUnit round:(MFTimeRoundMode)roundMode;
+ (NSString *)descriptiveStringFromInterval:(NSTimeInterval)interval endAction:(NSString *)endAction;
+ (NSDate *)alarmDateWithTodaysAlarmTime:(NSDate *)todaysAlarmTime tomorrowsAlarmTime:(NSDate *)tomorrowsAlarmTime;
+ (NSDate *)alarmDateWithAlarmTime:(NSDate *)alarmTime;
+ (NSTimeInterval)timeIntervalForNumber:(int)number withTimeUnit:(MFTimeUnit)timeUnit;
+ (NSString *)timeUnitStringWithAmount:(NSInteger)amount timeUnit:(MFTimeUnit)timeUnit;
+ (NSTimeInterval)updateIntervalForTimeInterval:(NSTimeInterval)duration;
+ (NSInteger)weekDayForDate:(NSDate *)date;

@end

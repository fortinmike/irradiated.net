//
//  NSColor+Additions.h
//  Buck
//
//  Created by Michaël Fortin on 12-06-04.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSColor (Additions)

+ (NSColor *)interpolateFrom:(NSColor *)fromColor to:(NSColor *)toColor percentage:(float)percentage;

- (NSColor *)interpolateFrom:(NSColor *)fromColor percentage:(float)percentage;
- (NSColor *)interpolateTo:(NSColor *)toColor percentage:(float)percentage;

@end

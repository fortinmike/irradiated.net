//
//  NSXMLNode+QueryAdditions.h
//  WeatherGrabber
//
//  Created by Michaël Fortin on 11-08-01.
//  Copyright 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSXMLNode (NSXMLNode_QueryAdditions)

- (NSString *)stringForXQuery:(NSString *)query;
- (NSNumber *)numberForXQuery:(NSString *)query;

@end

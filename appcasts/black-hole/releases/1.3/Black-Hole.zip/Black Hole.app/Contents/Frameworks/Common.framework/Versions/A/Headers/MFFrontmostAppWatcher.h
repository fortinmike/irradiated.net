//
//  MFFrontmostAppWatcher.h
//  Pauses
//
//  Created by Michaël Fortin on 11-12-28.
//  Copyright (c) 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MFFrontmostAppWatcher;

@protocol MFFrontmostAppWatcherDelegate <NSObject>

- (void)frontmostAppWatcher:(MFFrontmostAppWatcher *)appWatcher watchedAppBecameFrontmost:(NSString *)bundleIdentifier;
- (void)frontmostAppWatcherNoWatchedAppIsFrontmost:(MFFrontmostAppWatcher *)appWatcher;

@end

@interface MFFrontmostAppWatcher : NSObject {
	
	NSTimeInterval _updateInterval;
	
	NSMutableArray *_watchedBundleIdentifiers;
	NSString *_activeAppBundleIdentifier;
	NSString *_activeAppName;
	
}

@property (assign) id<MFFrontmostAppWatcherDelegate> delegate;

- (void)watchAppWithBundleIdentifier:(NSString *)bundleIdentifier;
- (void)unwatchAllApps;
- (BOOL)isWatchedApp:(NSString *)bundleIdentifier;
- (BOOL)isFrontmostAppWatched;
- (NSString *)frontmostAppBundleIdentifier;
- (NSString *)frontmostAppName;

@end

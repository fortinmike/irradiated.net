//
//  NSString+Additions.h
//  Common
//
//  Created by Michael Fortin on 12-07-23.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Additions)

- (NSArray *)stringsByExpandingPathWildcards;
- (BOOL)matchesPathWildcard:(NSString *)wildcard;
+ (NSString *)stringWithNumber:(NSNumber *)number decimals:(NSUInteger)decimals;

@end

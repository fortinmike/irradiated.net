//
//  MFGreaterThanValueTransformer.h
//  Buck
//
//  Created by Michaël Fortin on 12-06-04.
//  Copyright (c) 2012 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MFGreaterThanValueTransformer : NSValueTransformer

@property (assign) float number;

@end

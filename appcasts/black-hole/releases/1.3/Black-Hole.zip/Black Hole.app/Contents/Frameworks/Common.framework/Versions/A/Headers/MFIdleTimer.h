//
//  MFIdleTimer.h
//  Common
//
//  Created by Michaël Fortin on 11-11-19.
//  Copyright (c) 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MFIdleTimer : NSObject {
	
	id _target;
	SEL _selector;
	BOOL _repeats;
	
	NSTimer *_timer;
	
}

@property (assign) NSTimeInterval interval;

- (id)initWithTimeInterval:(NSInteger)interval target:(id)target selector:(SEL)selector;

+ (MFIdleTimer *)idleTimerWithTimeInterval:(NSInteger)interval target:(id)target selector:(SEL)selector;

- (void)invalidate;

@end

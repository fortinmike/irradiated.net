//
//  MFComputerManager.h
//  Sleepytime
//
//  Created by Michaël Fortin on 09-09-21.
//  Copyright 2009 Michaël Fortin. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#define MFComputerManagerShutdown 0
#define MFComputerManagerRestart 1
#define MFComputerManagerSleep 2
#define MFComputerManagerLogOut 3

#define ACTION_DELAY 3
#define FORCE_QUIT_DELAY 15
#define DONE_QUITTING_DELAY 5

@interface MFComputerManager : NSObject {
	
}

+ (void)shutdown;
+ (void)restart;
+ (void)sleep;
+ (void)logout;

+ (void)doAction;

@end

/*
 * Pulsar.h
 */

#import <AppKit/AppKit.h>
#import <ScriptingBridge/ScriptingBridge.h>


@class PulsarApplication;

enum PulsarPlayerState {
	PulsarPlayerStatePlaying = 'play' /* Audio is playing */,
	PulsarPlayerStatePaused = 'paus' /* Audio is paused, station is tuned but not playing audio */,
	PulsarPlayerStateStopped = 'stop' /* No audio is playing */
};
typedef enum PulsarPlayerState PulsarPlayerState;



/*
 * Pulsar Suite
 */

// The application's top-level scripting object.
@interface PulsarApplication : SBApplication

@property (copy, readonly) NSString *channelName;  // Name of the currently playing channel
@property (copy, readonly) NSString *channelNumber;  // Tuning number of the currently playing channel
@property (copy, readonly) NSData *channelLogo;  // Logo of the currently playing channel
@property (copy, readonly) NSData *rawChannelLogo;  // Unmodified logo of the currently playing channel
@property (copy, readonly) NSString *serviceName;  // Service name (SIRIUS, XM, etc) of the currently playing channel
@property (copy, readonly) NSString *trackTitle;  // Track title of currently playing channel
@property (copy, readonly) NSString *artist;  // Artist of currently playing channel
@property (copy, readonly) NSString *album;  // Album of currently playing channel
@property double audioVolume;  // Volume of the audio. Minimum volume is 0.0, maximimum is 1.0.
@property BOOL audioMuted;  // True if the audio is muted, false if not muted.
@property (readonly) PulsarPlayerState playerState;  // is Pulsar playing, paused or stopped?

- (void) playpause;  // Toggles playback between playing and paused.
- (void) next;  // Play the next Favorite channel.
- (void) previous;  // Play the previous Favorite channel.

@end


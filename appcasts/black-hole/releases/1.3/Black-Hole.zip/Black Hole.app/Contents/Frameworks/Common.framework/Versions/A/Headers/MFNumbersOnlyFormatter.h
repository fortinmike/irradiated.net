//
//  MFNumbersOnlyFormatter.h
//  Sleepytime
//
//  Created by Michaël Fortin on 09-09-20.
//  Copyright 2009 Michaël Fortin. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface MFNumbersOnlyFormatter : NSNumberFormatter {
	
}

@end

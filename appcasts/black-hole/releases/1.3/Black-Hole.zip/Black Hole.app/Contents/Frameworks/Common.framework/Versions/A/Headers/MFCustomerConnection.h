//
//  MFCustomerConnection.h
//  Common
//
//  Created by Michaël Fortin on 11-12-16.
//  Copyright (c) 2011 irradiated.net. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MFCustomerConnection : NSObject

+ (void)run;

@end
